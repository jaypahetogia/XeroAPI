#This file handles the transformation of the JSON data to the format required by Xero and the communication with the Xero API.

#Contents:
#Function to transform the JSON data into the format required by the Xero API (transform_for_xero).
#Function to send the data to the Xero API (send_invoice_to_xero).
#Handling of Xero API authentication and communication.

import requests
import config

def send_invoice_to_xero(invoice_data, xero_token):
    url = "https://api.xero.com/api.xro/2.0/Invoices"
    headers = {
        "Authorization": f"Bearer {xero_token}",
        "Content-Type": "application/json"
    }
    response = requests.post(url, headers=headers, json=invoice_data)
    return response.text

# Obtain your Xero OAuth token
xero_token = config.XERO_OAUTH_TOKEN
