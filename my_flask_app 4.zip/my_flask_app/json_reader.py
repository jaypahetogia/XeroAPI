import json

def read_json_file(file_path):
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
        return data
    except FileNotFoundError:
        print(f"The file {file_path} was not found.")
    except json.JSONDecodeError:
        print(f"Error decoding JSON from the file {file_path}.")

def transform_to_xero_format(data):
    xero_invoice = {
        "Type": "ACCREC",  # Assuming it's an accounts receivable invoice
        "Contact": {
            "Name": data["name"],
            "Addresses": [{
                "AddressType": "STREET",
                "AddressLine1": data["address"],
                "PostalCode": data["post code"]
            }]
        },
        "Date": data["date"],
        "DueDate": data["date"],  # You can adjust this as needed
        "LineItems": [{
            "Description": data["title"],
            "Quantity": data["quantity"],
            "UnitAmount": data["amount"],
            "AccountCode": "200",  # Replace with your account code
            # "TaxType": "YourTaxType",  # Uncomment and set your tax type if needed
        }],
        "Reference": data["reference"]
    }
    return xero_invoice

def main():
    # Path to your JSON file
    file_path = 'sendgrid_data.json'

    # Read JSON data from file
    json_data = read_json_file(file_path)

    # Transform JSON data to Xero format
    xero_invoice = transform_to_xero_format(json_data)

    # Print or do something with the Xero-formatted data
    print(xero_invoice)

if __name__ == "__main__":
    main()
