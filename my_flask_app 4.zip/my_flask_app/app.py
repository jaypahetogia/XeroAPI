from flask import Flask
import requests
import base64
import os
import jwt
import json_reader
import xero_integration
from flask import Flask, redirect, url_for, request

app = Flask(__name__)

# Define your Xero API credentials and redirect URI
CLIENT_ID = '92B4F89D7B6A47F4B592D93721DD8454'
CLIENT_SECRET = 'B0tCsqkG4z6ScVbd7Bmast1NhB-ggtN5bnlmYS3t3rlnZzl5'
REDIRECT_URI = 'http://localhost:3000/callback'

# Define the path to the file where tokens will be stored
TOKEN_FILE_PATH = '/Users/admin/Desktop/xero_tokens2.txt'

def save_tokens(access_token, refresh_token, tenant_id):
    # Implement logic to save tokens securely (e.g., in a database or encrypted file)
    print("tenantID: ", tenant_id)
    with open(TOKEN_FILE_PATH, 'w') as f:
        f.write(f"access_token={access_token}\n")
        f.write(f"refresh_token={refresh_token}\n")
        f.write(f"tenant_id={tenant_id}\n")

def get_refresh_token():
    if os.path.exists(TOKEN_FILE_PATH):
        with open(TOKEN_FILE_PATH, 'r') as f:
            tokens = f.readlines()
            for token in tokens:
                if token.startswith("refresh_token="):
                    refresh_token = token.split("=")[1].strip()
                    return refresh_token
    return None

def get_tenant_id():
    if os.path.exists(TOKEN_FILE_PATH):
        with open(TOKEN_FILE_PATH, 'r') as f:
            tokens = f.readlines()
            for token in tokens:
                if token.startswith("tenant_id="):
                    tenant_id = token.split("=")[1].strip()
                    return tenant_id
    return None

def refresh_access_token():
    token_url = "https://identity.xero.com/connect/token"
    headers = {
        "Authorization": "Basic " + base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode(),
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "grant_type": "refresh_token",
        "refresh_token": get_access_token()
    }
    response = requests.post(token_url, headers=headers, data=data)
    if response.status_code == 200:
        new_access_token = response.json().get("access_token")
        new_refresh_token = response.json().get("refresh_token")
        print(new_refresh_token)
        tenant_id = get_tenant_id()  # Retrieve tenant ID from storage
        # Save tokens and tenantID for future use
        save_tokens(new_access_token, new_refresh_token, tenant_id)
        return new_access_token
    else:
        # Handle the case where token refreshing fails
        print("Token refreshing failed")
        return "Token refreshing failed"
    
def get_access_token():
    if os.path.exists(TOKEN_FILE_PATH):
        with open(TOKEN_FILE_PATH, 'r') as f:
            tokens = f.readlines()
            access_token = None
            for token in tokens:
                if token.startswith("access_token="):
                    access_token = token.split("=")[1].strip()
                    break
            return access_token
    return None
#No tenant ID saved 
#Implement the create_invoice function to create an invoice in Xero
def create_invoice(xero_invoice, access_token, tenant_id):
    create_invoice_url = "https://api.xero.com/api.xro/2.0/Invoices"
    headers = {
        "Authorization": "Bearer " + access_token,
        "Content-Type": "application/json",
        "xero-tenant-id": tenant_id
    }
    response = requests.post(create_invoice_url, headers=headers, json=xero_invoice)
    if response.status_code == 200:
        return "Invoice created successfully"
    else:
        error_message = f"Failed to create invoice: {response.text}"
        print(error_message)
        return error_message

# Define the home route    
@app.route('/')
def home():
    print("request args: ", request.args)
    return "Welcome to the Invoice Creation App!!"

# Define the login route to start the OAuth 2.0 flow
@app.route('/login')
def login():
    # Redirect the user to the Xero authorization URL (same as before)
    xero_authorization_url = (
        "https://login.xero.com/identity/connect/authorize?"
        f"response_type=code&client_id={CLIENT_ID}&redirect_uri={REDIRECT_URI}"
        "&scope=openid profile email accounting.transactions&state=123"
    )
    print("xero_authorization_url: ", xero_authorization_url)
    return redirect(xero_authorization_url)

# Define the callback route to handle the authorization code automatically
@app.route('/callback')
def callback():
    # Get the authorization code from the query parameters
    code = request.args.get('code')
    print("request args: ", request.args)
    # Make a POST request to exchange the authorization code for an access token
    token_url = "https://identity.xero.com/connect/token"
    headers = {
        "Authorization": "Basic " + base64.b64encode(f"{CLIENT_ID}:{CLIENT_SECRET}".encode()).decode(),
        "Content-Type": "application/x-www-form-urlencoded"
    }
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": REDIRECT_URI
    }
    response = requests.post(token_url, headers=headers, data=data)
    print("response: ", response.json())
    # Handle the response
    if response.status_code == 200:
        access_token = response.json().get("access_token")
        refresh_token = response.json().get("refresh_token")
        tenant_id = check_tenants(access_token)
        save_tokens(access_token, refresh_token, tenant_id)
        
        return "Authorization successful. You can now create invoices."
    else:
        return "Failed to exchange the authorization code for an access token."


def check_tenants(access_t):
    t_response = requests.get("https://api.xero.com/connections", headers={"Authorization": "Bearer " + access_t, "Content-Type": "application/json"})
    print("tenants: ", t_response.json())
    #GET https://api.xero.com/connections
#Authorization: "Bearer " + access_token
#Content-Type: application/json
    
    response_data = t_response.json()

# Iterate over the list to find the dictionary with 'tenantName' as 'Demo Company (NZ)'
    for item in response_data:
        if item['tenantName'] == 'Demo Company (NZ)':
            tenant_id_demo = item['tenantId']
            print("Demo ID: ", tenant_id_demo)
            return tenant_id_demo
    return None

# Define the create_invoice route to create an invoice in Xero once authorized
@app.route('/create_invoice')
def create_invoice_route():
    # Check if access token is expired or about to expire
    access_token = get_access_token()
    if access_token is None:
        access_token = refresh_access_token()
    if access_token:
        # Proceed with invoice creation using the refreshed access token
        tenant_id = get_tenant_id()

        # Replace this example invoice data with your actual data
        xero_invoice = {
            "Type": "ACCREC",
            "Contact": {
                "Name": "Customer Name",
                "Addresses": [{
                    "AddressType": "STREET",
                    "AddressLine1": "123 Main Street",
                    "PostalCode": "12345"
                }]
            },
            "Date": "2023-01-01",
            "DueDate": "2023-01-15",
            "LineItems": [{
                "Description": "Example Item",
                "Quantity": 1,
                "UnitAmount": 100.00,
                "AccountCode": "200"
            }], 
            "Reference": "INV-001"
        }
        result = create_invoice(xero_invoice, access_token, tenant_id)
        return result
    else:
        return "Failed to create invoice. Unable to obtain access token."

if __name__ == '__main__':
    app.run(host='localhost', port=3000, debug=True)